﻿Configuration Configfailover {

    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    # The Node statement specifies which targets this configuration will be applied to.
    Node 'localhost' {

 
WindowsFeature FC
{
Name = "Failover-Clustering"
Ensure = "Present"
}

WindowsFeature FailoverClusterTools 
{ 
Ensure = "Present" 
Name = "RSAT-Clustering-Mgmt"
DependsOn = "[WindowsFeature]FC"
} 

WindowsFeature FCPS
{
Name = "RSAT-Clustering-PowerShell"
Ensure = "Present"
DependsOn = "[WindowsFeature]FailoverClusterTools"
}

WindowsFeature ADPS
{
Name = "RSAT-AD-PowerShell"
Ensure = "Present"
DependsOn = "[WindowsFeature]FCPS"
} 
 
    
}
}